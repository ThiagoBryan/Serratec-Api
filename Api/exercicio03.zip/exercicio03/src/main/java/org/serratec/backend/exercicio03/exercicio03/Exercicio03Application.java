package org.serratec.backend.exercicio03.exercicio03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio03Application {

	public static void main(String[] args) {
		SpringApplication.run(Exercicio03Application.class, args);
	}

}
