package org.serratec.backend.exercicioContaBancaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioContaBancariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
