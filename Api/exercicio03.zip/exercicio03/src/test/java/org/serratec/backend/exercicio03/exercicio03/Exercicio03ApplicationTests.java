package org.serratec.backend.exercicio03.exercicio03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercicio03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
