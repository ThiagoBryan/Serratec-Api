package org.serratec.backend.borracharia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BorrachariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BorrachariaApplication.class, args);
	}

}
